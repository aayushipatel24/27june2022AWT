function PropmptExternalJS() {
    document.getElementById("mainimgid").src="../CSS/Images/abc.jpg";
}

function PropmptExternalJS1() {
    document.getElementById("mainimgid").src="../CSS/Images/pqr.jpg";
}

function PropmptExternalJS2() {
    document.getElementById("mainimgid").src="../CSS/Images/xyz.jpg";
}